#pragma once
#include <net/http/http_client.h>
#include <net/ipaddress.h>

class AuditTrailHttpClient : public Net::Http::Client
{
public:
	explicit AuditTrailHttpClient(Net::IpAddress interface = Net::IpAddress::any()) : Client(interface)
	{

	}

	~AuditTrailHttpClient() {}

	template <typename _function>
	Future<Client::Response> post(const Uri &uri, _function &&produceContent)
	{
		Header header;

		header.setRequest(Version::Http11, Method::Post, uri);
		header.addField("Content-Type", "application/fhir+json");
		header.addField("Host", "localhost:8181");


		auto result = sendRecv(std::move(header));
		if (result.first)
			produceContent(*result.first);

		return std::move(result.second);
	}


};