#include "stdafx.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <net\http\http_client.h>
#include <net\http\http_server.h>
#include <net\icmpsocket.h>
#include <net\ipaddress.h>

using namespace std;

enum cateogry { start };
enum Outcom { ou };

struct NodeInfo
{
	NodeInfo(std::string xyz = "xyz1",
		std::string xyz2 = "xyz2",
		std::string xyz3 = "xyz3"):a(xyz),b(xyz2),c(xyz3)
	{

	}

		std::string a;
		std::string b;
		std::string c;
};

struct eventbalue
{
	cateogry msgCategory;
	Outcom  outcome;
	std::string processName = "test";
}; eventbalue eventValues_in;

//namespace Net {
//	namespace Http {
//
//		class AuditTrailHttpClient : public Client
//		{
//		public:
//			explicit AuditTrailHttpClient(IpAddress interface = IpAddress::any()) : Client(interface)
//			{
//
//			}
//
//			~AuditTrailHttpClient() {}
//
//			template <typename _function>
//			Future<Client::Response> post(const Uri &uri, _function &&produceContent)
//			{
//				Header header;
//
//				header.setRequest(Version::Http11, Method::Post, uri);
//				header.addField("Content-Type", "application/fhir+json");
//				header.addField("Host", "localhost:8181");
//
//
//				auto result = sendRecv(std::move(header));
//				if (result.first)
//					produceContent(*result.first);
//
//				return std::move(result.second);
//			}
//
//
//		};
//
//	}
//}
/*leaf node code 

stack<Node*> s;


while (true)
{
if(root != NULL)
{
s.push(root);
root = root->left;
}
else
{
if(s.empty())
break;

auto temp = s.top();
if(isLeaf(temp))
{
cout<< temp->data;
}

root = temp->right;
s.pop();
}

}

/*

void assignNodeToArray(Node *root, map<int,vector<Node*>> &mapValu_in,int h)
{
if(root == NULL)
return;

mapValu_in[h].push_back(root);
assignNodeToArray(root->left,mapValu_in,h-1);
assignNodeToArray(root->right,mapValu_in,h+1);


}
bool isLeaf(Node* root)
{
if(root->left == NULL && root->right == NULL)
return true;
else
return false;

}

void printValue( map<int,vector<Node*>> &mapValu_in)
{
for (auto & itr : mapValu_in )
{
auto vec = itr.second ;
if(vec.size() >1)
{
for (auto it = vec.rbegin(); it != vec.rend(); it++)
{
if(isLeaf(*it))
{
cout << (*it)->data <<" ";
break;
}
}
}
else
{
cout << vec.back()->data <<" ";
}

}

}
// Method that prints the bottom view.
void bottomView(Node *root)
{
if(root == NULL)
return;

if(root->left == NULL && root->right == NULL)
{
cout<<root->data << " ";
return;
}

map<int,vector<Node*>> mapValue;

assignNodeToArray(root,mapValue,0);

printValue(mapValue);
}

coorect answer
void bottomView(Node *root)
{
map<int,int>data;
int hd=0;
queue<pair<Node*,int>>q;
q.push(make_pair(root,hd));

while(!q.empty())
{
Node * cur=q.front().first;
hd=q.front().second;
data[hd]=cur->data;

if(cur->left!=NULL)
{
q.push(make_pair(cur->left,hd-1));
}

if(cur->right!=NULL)
{
q.push(make_pair(cur->right,hd+1));
}
q.pop();
}
for(auto it:data)
{
cout<<it.second<<" ";
}
}
*/


//void leftView(Node *root)
//{
//	queue<Node*> q;
//	q.push(root);
//	q.push(NULL);
//	bool isAllowed = true;
//
//	while (!q.empty())
//	{
//		auto node = q.front();
//
//		q.pop();
//		if (node != NULL && isAllowed)
//		{
//			cout << node->data << " ";
//			isAllowed = false;
//		}
//
//		if (node == NULL && !q.empty())
//		{
//			q.push(node);
//			isAllowed = true;
//		}
//
//		if (node != NULL)
//		{
//			q.push(node->left);
//		}
//
//		if (node != NULL)
//		{
//			q.push(node->right);
//
//		}
//
//
//
//	}
//
//
//}

int main34()
{

	stringstream s;
	s << "{ \"root\": { \"values\": [1, 2, 3, 4, 5 ] } }";

	auto val = s.str();


	NodeInfo node;

	std::vector<NodeInfo> vec;
	NodeInfo a("a1", "b1", "c1");
	NodeInfo b("a2", "b2", "c2");
	vec.emplace_back(a);
	vec.emplace_back(b);

	std::stringstream ss;
	ss << "{" << "\"root\"" << ":" << "{" << "\"msgCategory\"" << "\:" << "\"" << eventValues_in.msgCategory << "\"" << ","
		<< "\"outcome\"" << ":" << "\"" << eventValues_in.outcome << "\"" << "," <<
		"\"processName\"" << ":" << "\"" << eventValues_in.processName.c_str() << "\"" << ","
		<< "\"node\"" << "\:" << "{"
		<< "\"node.a \"" << "\:" << "\"" << node.a << "\"" << "," << "\"node.b\"" << "\:"
		<< "\"" << node.b << "\"" << "," << "\"node.c\"" << "\:" << "\"" << node.c << "\"" << "}" << "," 
		<< "\"vec\"" << "\:"<<"["
		<<"{" << "\"Vec[0]\"" << "\:" << "{"
		<< "\"node.a \"" << "\:" << "\"" << vec[0].a << "\"" << "," << "\"node.b\"" << "\:"
		<< "\"" << vec[0].b << "\"" << "," << "\"node.c\"" << "\:" << "\"" << vec[0].c << "\"" << "}" <<"}"","
		<<"{"<< "\"Vec[1]\"" << "\:" << "{"
		<< "\"node.a \"" << "\:" << "\"" << vec[1].a << "\"" << "," << "\"node.b\"" << "\:"
		<< "\"" << vec[1].b << "\"" << "," << "\"node.c\"" << "\:" << "\"" << vec[1].c << "\"" << "}" <<"}"
		<<"]"
		<<"}""}";

	string jsonString = ss.str();
		
	return 0;
}