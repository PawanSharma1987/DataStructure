// sampleApplication.cpp : Defines the entry point for the console application.
//
//This is sample code for trie data structure insert search and delete implementaion in c++.

#include "stdafx.h"
#include <iostream>
#include <string>
#include <map>
#include <sstream>


using namespace std;

struct TrieNode
{
	std::map<char, struct TrieNode *> child;
	bool isEndofWord;
};

struct TrieNode* getNode()
{
	struct TrieNode *temp = new TrieNode;
	temp->isEndofWord = false;
	return temp;
}

void insert(struct TrieNode* root, std::string str)
{
	struct TrieNode* temp = root;

	for (int j = 0; j < str.length(); ++j)
	{
		auto mapitr = temp->child.find(str[j]);

		if (mapitr != temp->child.end())
		{
			temp = temp->child[str[j]];
			continue;
		}	
		temp->child[str[j]] = getNode();
		temp = temp->child[str[j]];
	}
	temp->isEndofWord = true;
}

bool Serach(struct TrieNode* root, std::string str)
{
	struct TrieNode* temp = root;

	for (int j = 0; j < str.length(); ++j)
	{
		auto mapitr = temp->child.find(str[j]);
		if (mapitr != temp->child.end())
		{
			temp = temp->child[str[j]];
		}
		else
		{
			return false;
		}
	}
	if (temp->isEndofWord)
	{
		cout << str.c_str() << endl;
		return true;
	}

	return false;

}

bool deleteWord(struct TrieNode* root, std::string word, int index)
{
	if (index == word.length()) {
		
		if (!root->isEndofWord) {
			return false;
		}
		root->isEndofWord = false;
		
		return root->child.size() == 0;
	}

	char ch = word[index];
	TrieNode* node = root->child[ch];

	if (node == nullptr) {
		return false;
	}

	bool val = deleteWord(node, word, index + 1);
		
	if (val) {
		root->child.erase(ch);		
		return root->child.size() == 0;
	}
	return false;
	
}

void deleteNode(struct TrieNode* root, std::string str)
{	
		deleteWord(root, str, 0);
}









int main1()
{
	std::string value[] = { "abc","ghk","abijk" };
	int size = sizeof(value) / sizeof(value[0]);
	
	struct TrieNode* root = getNode();

	for (int i = 0; i < size; ++i)
	{
		insert(root, value[i]);
	}

	cout << "result : " << Serach(root, "abc") << endl;
	cout << "result : " << Serach(root, "abijk") << endl;

	/*cout << "result : " << Serach(root, "def") << endl;
	cout << "result : " << Serach(root, "") << endl;
	cout << "result : " << Serach(root, "ab") << endl;
	cout << "result : " << Serach(root, "abi") << endl;*/

	struct TrieNode* temp = root;
	deleteNode(temp, "abc");

	cout << "result : " << Serach(root, "abc") << endl;
	cout << "result : " << Serach(root, "abijk") << endl;
	cin.get();

	

    return 0;
}

