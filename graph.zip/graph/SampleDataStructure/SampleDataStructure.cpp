// SampleDataStructure.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include<vector>
#include <queue>
#include <stack>

using namespace std;

// undirected Graph


struct graph
{
	std::vector<int>*adj;
	const int node;
public:
	graph(const int v):node(v)
	{
		adj = new std::vector<int>[node];
	}

	void addEdge(int i, int j)
	{
		adj[i].push_back(j);		
	}
	void printDFSGraph(int index)
	{
		bool *visited = new bool[index];
		for (int i = 0; i < node; i++)
			visited[i] = false;

		std::stack<int> q;
		visited[index] = true;
		q.push(index);

		while (!q.empty())
		{
			auto i = q.top();
			cout << " index value -> " << i << " ";
			q.pop();
			for (auto itr = adj[i].begin(); itr != adj[i].end(); ++itr)
			{
				if (!visited[*itr])
				{
					visited[*itr] = true;
					q.push(*itr);
				}

			}
		}
	}
	void printBFSGraph(int index)
	{
		bool *visited = new bool[index];
		for (int i = 0; i < node; i++)
			visited[i] = false;

		std::queue<int> q;
		visited[index] = true;
		q.push(index);

		while (!q.empty())
		{
			auto i = q.front();			
			cout << " index value -> " << i <<" ";
			q.pop();
			for (auto itr = adj[i].begin(); itr != adj[i].end(); ++itr)
			{
				if (!visited[*itr])
				{
					visited[*itr] = true;
					q.push(*itr);
				}
					
			}
		}

		/*for (int i = 0; i < index; ++i)
		{
			auto val = adj[i];
			cout << "\n Adjacency list of vertex "
				<< i << "\n head ";
			for (auto &v : val)
			{
				cout << v << "-> " << endl;
			}

		}*/
	}
};

int main()
{	
	graph g(4);
	g.addEdge(0, 1);
	g.addEdge(0, 2);
	g.addEdge(1, 2);
	g.addEdge(2, 0);
	g.addEdge(2, 3);
	g.addEdge(3, 3);

	cout << "Following is Breadth First Traversal "
		<< "(starting from vertex 2) \n"  ;

	g.printBFSGraph(0);

	cout << endl <<"Following is Deapth First Traversal "
		<< "(starting from vertex 2) \n";
	g.printDFSGraph(0);

	cin.get();
    return 0;
}

